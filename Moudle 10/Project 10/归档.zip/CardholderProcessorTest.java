import org.junit.Assert;
import org.junit.Test;
import java.io.FileNotFoundException;
 /** 	
  * CardholderProcessor class.
  *	
  * @author Xi Rao
  * @version 11/16/2018
  */	

public class CardholderProcessorTest {
   /**.
*/
   @Test public void getTest() { 
      CardholderProcessor ab = new CardholderProcessor();
      String[] a = {};
      String[] b = {"cardholder_data_1.txt"};
      Assert.assertEquals("getInvalidRecords Test",
         0, ab.getInvalidRecordsArray().length);
      Assert.assertEquals("getCardholder Test",
         0, ab.getCardholdersArray().length);    
   }      
   /** 
    * A test for readCardholderFile().
    * @throws FileNotFoundException throws an exception if no file found.
    */
   @Test public void readCardholderFileTest() throws FileNotFoundException {
      CardholderProcessor cList = new CardholderProcessor();
      String name = "Monthly Cardholder";
      cList.readCardholderFile("cardholder_data_1.txt");
      Assert.assertTrue(name.contains("Monthly Cardholder"));
   }
   
  /**.
   */
   @Test public void addInvalidRecordTest() {
      CardholderProcessor rx = new CardholderProcessor();
      SapphireCardholder e = new SapphireCardholder("10001", "Smith, Sam");
      e.addPurchases(34.5, 100.0, 63.50, 300.0);
      double[] purchases = {63.5};
      e.setPurchases(purchases);
      rx.addCardholder(e);
      Assert.assertEquals("addInvalidRecord Test",
         rx.getCardholdersArray()[0], e);
   }
   /** 
    * A test for generateReportByClass().
    * @throws FileNotFoundException throws an exception if no file found.
    */
   @Test public void generateReportByClassTest() throws FileNotFoundException {
      CardholderProcessor clist = new CardholderProcessor();
      clist.readCardholderFile("cardholder_data_1.txt");  
      Assert.assertFalse("generateReportByClass Test",
         clist.generateReportByName().contains("cardholder"));
   }
    /** 
    * A test for generateReportByPrice().
    * @throws FileNotFoundException throws an exception if no file found.
    */
   @Test public void generateReportByPriceTest() throws FileNotFoundException {
      CardholderProcessor clist = new CardholderProcessor();
      clist.readCardholderFile("cardholder_data_1.txt");
      Assert.assertFalse("generateReportByClass Test",
         clist.generateReportByCurrentBalance().contains("cardholder")); 
   }
}