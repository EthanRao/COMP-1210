import org.junit.Assert;
import static org.junit.Assert.*;
//import org.junit.Before;
import org.junit.Test;


public class SapphireCardholderTest {



   /** A test that always fails. **/
   @Test public void defaultTest() {
      Assert.assertEquals("Default test added by jGRASP. Delete "
            + "this test once you have added your own.", 0, 1);
   }
   /**.
   */
   @Test public void compareToTest() {
      SapphireCardholder sc = new SapphireCardholder("10001", "Smith, Sam");
      Cardholder nameIn = new SapphireCardholder("10001", "Smith, Sam");;
      Assert.assertEquals("compareTo Test", 0, sc.compareTo(nameIn));
   }
   
}
