import org.junit.Assert;
import org.junit.Test;

/**
 * A Test class of Cardholder Part2 App.
 *
 * Project 10.
 * @author Xi Rao
 * @version 11/16/2018
 */


public class CardholdersPart2AppTest {
   /**
    * A test for main when reads no file.
    * @throws Exception throws an exception if no file found.
    */
   @Test public void mainTest1() throws Exception {
      CardholderProcessor.resetListCount();
      CardholdersPart2 app = new CardholdersPart2();
      String[] args1 = {"cardholder_data_0"};
      CardholdersPart2.main(args1);
      Assert.assertEquals(0, CardholderProcessor.getListCount());
   }
   
   /**
    * A test for main when the file exists.
    * @throws Exception throws an exception if no file found.
    */
   @Test public void mainTest2() throws Exception {
      CardholderProcessor.resetListCount();
      CardholdersPart2 app = new CardholdersPart2();
      String[] args2 = {"cardholder_data_1"};
      CardholdersPart2.main(args2);
      Assert.assertEquals(1, CardholderProcessor.getListCount());
   }
}